Sparse Matrices in SciPy
========================

**Author**: *Robert Cimrman*

|

.. toctree::
   :maxdepth: 3

   introduction
   storage_schemes
   solvers
   other_packages
