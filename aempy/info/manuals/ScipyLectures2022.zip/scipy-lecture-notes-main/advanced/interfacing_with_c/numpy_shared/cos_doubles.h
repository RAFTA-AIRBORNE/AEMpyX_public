void cos_doubles(double * in_array, double * out_array, int size);
