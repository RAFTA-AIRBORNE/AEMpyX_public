Examples for the mathematical optimization chapter
==================================================
