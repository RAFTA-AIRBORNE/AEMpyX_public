

Example demoing choices for an option
--------------------------------------
