Full code examples for the scipy chapter
-----------------------------------------
