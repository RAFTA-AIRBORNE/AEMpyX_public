.. only:: latex

   =============================
   About the SciPy lecture notes
   =============================


   About the SciPy lecture notes
   =============================

   Release: |release|

   The lecture notes are archived on zenodo: http://dx.doi.org/10.5281/zenodo.594102

   All code and material is licensed under a
   Creative Commons Attribution 4.0 International License (CC-by)
   http://creativecommons.org/licenses/by/4.0/

   .. raw:: latex

      \begin{multicols}{2}

   .. toctree::

      AUTHORS.rst

   .. raw:: latex

      \end{multicols}
