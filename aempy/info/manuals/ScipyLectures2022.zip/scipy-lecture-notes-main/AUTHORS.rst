
Authors
========

Editors
--------

- Gaël Varoquaux

- Emmanuelle Gouillart

- Olav Vahtras

- Pierre de Buyl

Chapter authors
----------------

Listed by alphabetical order.

- Christopher Burns

- Adrian Chauve

- Robert Cimrman

- Christophe Combelles

- André Espaze

- Emmanuelle Gouillart

- Mike Müller

- Fabian Pedregosa

- Didrik Pinte

- Nicolas Rougier

- Gaël Varoquaux

- Pauli Virtanen

- Zbigniew Jędrzejewski-Szmek

- Valentin Haenel (editor from 2011 to 2015)

Additional Contributions
------------------------

Listed by alphabetical order

- Osayd Abdu

- arunpersaud

- Ross Barnowski

- Sebastian Berg

- Lilian Besson

- Matthieu Boileau

- Joris Van den Bossche

- Michael Boyle

- Matthew Brett

- BSGalvan

- Lars Buitinck

- Pierre de Buyl

- Ozan Çağlayan

- Lawrence Chan

- Adrien Chauve

- Robert Cimrman

- Christophe Combelles

- David Cournapeau

- Dave

- dogacan dugmeci

- Török Edwin

- egens

- Andre Espaze

- André Espaze

- Loïc Estève

- Corey Farwell

- Tim Gates

- Stuart Geiger

- Olivier Georg

- Daniel Gerigk

- Robert Gieseke

- Philip Gillißen

- Ralf Gommers

- Emmanuelle Gouillart

- Julia Gustavsen

- Omar Gutiérrez

- Valentin Haenel

- Pierre Haessig

- Bruno Hanzen

- Michael Hartmann

- Jonathan Helmus

- Andreas Hilboll

- Himanshu

- Julian Hofer

- Tim Hoffmann

- B. Hohl

- Tarek Hoteit

- Gert-Ludwig Ingold

- Zbigniew Jędrzejewski-Szmek

- Thouis (Ray) Jones

- jorgeprietoarranz

- josephsalmon

- Greg Kiar

- kikocorreoso

- Vince Knight

- LFP6

- Manuel López-Ibáñez

- Marco Mangan

- Nicola Masarone

- John McLaughlin

- mhemantha

- michelemaroni89

- Mohammad

- Zachary Moon

- Mike Mueller

- negm

- John B Nelson

- nicoguaro

- Sergio Oller

- Theofilos Papapanagiotou

- patniharshit

- Fabian Pedregosa

- Philippe Pepiot

- Tiago M. D. Pereira

- Nicolas Pettiaux

- Didrik Pinte

- Evgeny Pogrebnyak

- reverland

- Maximilien Riehl

- Kristian Rother

- Nicolas P. Rougier

- Nicolas Rougier

- Rutzmoser

- Sander

- João Felipe Santos

- Mark Setchell

- Helen Sherwood-Taylor

- Shoeboxam

- Simon

- solarjoe

- ssmiller

- Scott Staniewicz

- strpeter

- surfer190

- Bartosz Telenczuk

- tommyod

- Wes Turner

- Akihiro Uchida

- Utkarsh Upadhyay

- Olav Vahtras

- Gael Varoquaux

- Nelle Varoquaux

- Olivier Verdier

- VirgileFritsch

- Pauli Virtanen

- Yosh Wakeham

- Stefan van der Walt

- yasutomo57jp
